export class Team {

constructor(public id: number, public name: string, public shortName: string, public crestURL: string) {}

}
